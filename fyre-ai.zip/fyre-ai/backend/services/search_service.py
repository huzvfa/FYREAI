"""
FYRE AI — Web Search Service
Uses DuckDuckGo (100% free, no API key required)
Provides real-time web context like Perplexity AI
"""

from duckduckgo_search import DDGS
from typing import Optional
import asyncio


def _sync_search(query: str, max_results: int = 5) -> list[dict]:
    """Synchronous DuckDuckGo search"""
    results = []
    with DDGS() as ddgs:
        for r in ddgs.text(query, max_results=max_results):
            results.append({
                "title": r.get("title", ""),
                "snippet": r.get("body", ""),
                "url": r.get("href", ""),
            })
    return results


async def web_search(query: str, max_results: int = 5) -> list[dict]:
    """Async web search using DuckDuckGo"""
    loop = asyncio.get_event_loop()
    results = await loop.run_in_executor(None, _sync_search, query, max_results)
    return results


def format_context(results: list[dict]) -> str:
    """Format search results into context for the AI"""
    if not results:
        return ""
    
    lines = []
    for i, r in enumerate(results, 1):
        lines.append(f"[{i}] {r['title']}")
        lines.append(f"    {r['snippet']}")
        lines.append(f"    Source: {r['url']}")
        lines.append("")
    
    return "\n".join(lines)


def should_search(message: str) -> bool:
    """Heuristic: decide if a query needs web search"""
    triggers = [
        "latest", "recent", "today", "news", "2024", "2025", "current",
        "who is", "what is", "when did", "price of", "weather",
        "stock", "score", "result", "happened", "update",
        "how to install", "download", "release"
    ]
    msg_lower = message.lower()
    return any(t in msg_lower for t in triggers)
