"""
FYRE AI — Ollama LLM Service
Connects to locally running Ollama for free, private AI inference
"""

import httpx
import json
from typing import AsyncIterator

OLLAMA_URL = "http://localhost:11434"
OLLAMA_MODEL = "mistral"  # Change to: llama3, phi3, codellama, etc.

SYSTEM_PROMPT = """You are FYRE AI — a highly intelligent, friendly, and capable AI assistant. 
You are designed to:
- Answer student questions with clear, step-by-step explanations
- Solve math, science, coding, and essay problems accurately
- Search the web and provide up-to-date information when needed
- Be conversational, warm, and encouraging
- Be concise yet thorough — no fluff, just value

You always format your responses clearly. For math/science, show your work step by step.
For code, use proper code blocks. For essays, provide structured, original content.
Never say you cannot do something without trying first."""


async def stream_response(messages: list, context: str = "") -> AsyncIterator[str]:
    """Stream AI response token by token from Ollama"""
    
    system = SYSTEM_PROMPT
    if context:
        system += f"\n\n## Web Search Results (use these for current info):\n{context}"

    payload = {
        "model": OLLAMA_MODEL,
        "messages": [{"role": "system", "content": system}] + messages,
        "stream": True,
        "options": {
            "temperature": 0.7,
            "top_p": 0.9,
            "num_predict": 2048,
        }
    }

    async with httpx.AsyncClient(timeout=120.0) as client:
        async with client.stream("POST", f"{OLLAMA_URL}/api/chat", json=payload) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if line.strip():
                    try:
                        data = json.loads(line)
                        if "message" in data and "content" in data["message"]:
                            token = data["message"]["content"]
                            if token:
                                yield token
                        if data.get("done"):
                            break
                    except json.JSONDecodeError:
                        continue


async def get_response(messages: list, context: str = "") -> str:
    """Get full (non-streaming) response from Ollama"""
    full = ""
    async for token in stream_response(messages, context):
        full += token
    return full


async def check_ollama_status() -> dict:
    """Check if Ollama is running and which models are available"""
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            r = await client.get(f"{OLLAMA_URL}/api/tags")
            models = [m["name"] for m in r.json().get("models", [])]
            return {"status": "online", "models": models, "active_model": OLLAMA_MODEL}
    except Exception as e:
        return {"status": "offline", "error": str(e), "fix": "Run: ollama serve"}
