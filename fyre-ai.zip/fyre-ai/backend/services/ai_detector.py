"""
FYRE AI — AI Text Detector
Detects whether text was likely written by AI using linguistic heuristics.
No API key needed — runs entirely locally.
"""

import re
import math
from collections import Counter


def calculate_perplexity_score(text: str) -> float:
    """
    Estimate text 'perplexity' — AI text tends to be lower perplexity
    (more predictable, uniform sentence lengths, less variance)
    """
    sentences = re.split(r'[.!?]+', text)
    sentences = [s.strip() for s in sentences if len(s.strip()) > 5]
    
    if len(sentences) < 2:
        return 0.5
    
    lengths = [len(s.split()) for s in sentences]
    avg = sum(lengths) / len(lengths)
    variance = sum((l - avg) ** 2 for l in lengths) / len(lengths)
    
    # High variance = more human-like
    # Low variance = more AI-like
    return min(variance / 50, 1.0)


def check_ai_patterns(text: str) -> dict:
    """Check for common AI writing patterns"""
    score_factors = []
    flags = []

    # 1. Transition word overuse (AI loves these)
    ai_transitions = [
        "furthermore", "moreover", "additionally", "in conclusion",
        "it is important to note", "it is worth noting", "in summary",
        "overall", "in essence", "to summarize", "as mentioned",
        "delve into", "it's essential", "crucial", "landscape"
    ]
    text_lower = text.lower()
    transition_count = sum(text_lower.count(t) for t in ai_transitions)
    if transition_count >= 3:
        score_factors.append(0.8)
        flags.append(f"Heavy use of AI transition phrases ({transition_count} found)")
    elif transition_count >= 1:
        score_factors.append(0.5)

    # 2. Sentence length uniformity
    sentences = re.split(r'[.!?]+', text)
    sentences = [s.strip() for s in sentences if len(s.strip()) > 5]
    if len(sentences) >= 3:
        lengths = [len(s.split()) for s in sentences]
        avg = sum(lengths) / len(lengths)
        variance = sum((l - avg) ** 2 for l in lengths) / len(lengths)
        if variance < 15:
            score_factors.append(0.75)
            flags.append("Very uniform sentence lengths (AI characteristic)")
        elif variance < 30:
            score_factors.append(0.5)

    # 3. Passive voice overuse
    passive_patterns = [r'\bwas\b', r'\bwere\b', r'\bhas been\b', r'\bhave been\b']
    passive_count = sum(len(re.findall(p, text_lower)) for p in passive_patterns)
    word_count = len(text.split())
    passive_ratio = passive_count / max(word_count, 1)
    if passive_ratio > 0.06:
        score_factors.append(0.65)
        flags.append("High passive voice usage")

    # 4. Repetitive word use
    words = re.findall(r'\b[a-z]{4,}\b', text_lower)
    if words:
        word_freq = Counter(words)
        top_freq = word_freq.most_common(5)
        if top_freq and top_freq[0][1] / len(words) > 0.04:
            score_factors.append(0.6)
            flags.append(f"Repetitive vocabulary ('{top_freq[0][0]}' overused)")

    # 5. Lack of personal pronouns (AI avoids I/we/my)
    personal = len(re.findall(r'\b(I|me|my|we|our|I\'m|I\'ve)\b', text))
    if personal == 0 and word_count > 100:
        score_factors.append(0.7)
        flags.append("No first-person pronouns detected")

    # 6. Perfect grammar score (AI rarely makes typos)
    contraction_count = len(re.findall(r"\b\w+'\w+\b", text))
    if contraction_count == 0 and word_count > 80:
        score_factors.append(0.6)
        flags.append("No contractions — very formal/AI-like tone")

    return {"score_factors": score_factors, "flags": flags}


def detect_ai_text(text: str) -> dict:
    """
    Main detection function.
    Returns probability score (0.0 = human, 1.0 = AI) with reasoning.
    """
    if not text or len(text.strip()) < 30:
        return {
            "ai_probability": 0,
            "verdict": "Text too short to analyze",
            "confidence": "low",
            "flags": [],
        }

    perplexity_score = calculate_perplexity_score(text)
    pattern_result = check_ai_patterns(text)
    
    all_scores = pattern_result["score_factors"] + [1.0 - perplexity_score]
    
    if all_scores:
        ai_probability = sum(all_scores) / len(all_scores)
    else:
        ai_probability = 0.2  # Default: likely human
    
    ai_probability = round(min(max(ai_probability, 0.0), 1.0), 2)
    
    # Verdict
    if ai_probability >= 0.75:
        verdict = "Likely AI-generated"
        confidence = "high"
    elif ai_probability >= 0.50:
        verdict = "Possibly AI-generated"
        confidence = "medium"
    elif ai_probability >= 0.30:
        verdict = "Mostly human-written"
        confidence = "medium"
    else:
        verdict = "Likely human-written"
        confidence = "high"

    return {
        "ai_probability": ai_probability,
        "ai_percentage": f"{int(ai_probability * 100)}%",
        "verdict": verdict,
        "confidence": confidence,
        "flags": pattern_result["flags"],
        "word_count": len(text.split()),
    }
