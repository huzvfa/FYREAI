"""
FYRE AI — File Parser Service
Extracts text from PDF, DOCX, and TXT files
"""

import io
from pathlib import Path


async def parse_file(filename: str, content: bytes) -> dict:
    """Parse uploaded file and return extracted text"""
    ext = Path(filename).suffix.lower()
    
    try:
        if ext == ".pdf":
            return await _parse_pdf(content)
        elif ext in [".docx", ".doc"]:
            return await _parse_docx(content)
        elif ext == ".txt":
            return await _parse_txt(content)
        else:
            return {"error": f"Unsupported file type: {ext}", "text": ""}
    except Exception as e:
        return {"error": str(e), "text": ""}


async def _parse_pdf(content: bytes) -> dict:
    import fitz  # PyMuPDF
    doc = fitz.open(stream=content, filetype="pdf")
    text = ""
    for page in doc:
        text += page.get_text()
    doc.close()
    return {
        "text": text.strip(),
        "pages": doc.page_count if hasattr(doc, 'page_count') else 0,
        "type": "pdf"
    }


async def _parse_docx(content: bytes) -> dict:
    from docx import Document
    doc = Document(io.BytesIO(content))
    text = "\n".join([para.text for para in doc.paragraphs])
    return {
        "text": text.strip(),
        "type": "docx"
    }


async def _parse_txt(content: bytes) -> dict:
    text = content.decode("utf-8", errors="replace")
    return {
        "text": text.strip(),
        "type": "txt"
    }
