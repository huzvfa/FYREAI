"""
FYRE AI — Plagiarism Remover Service
Rewrites text to be unique, original, and human-sounding
Uses the local AI model — no external APIs needed
"""

from services.ollama_service import get_response


REWRITE_PROMPT = """You are an expert writer and editor. Your task is to COMPLETELY rewrite the provided text so that:

1. It is 100% original and plagiarism-free
2. It preserves the exact same meaning, facts, and information
3. It sounds natural and human-written
4. The vocabulary, sentence structure, and phrasing are completely changed
5. The flow and tone are improved and engaging
6. No sentence should remain unchanged from the original

Provide ONLY the rewritten text, no explanations or commentary."""


async def remove_plagiarism(text: str) -> dict:
    """Rewrite text to remove plagiarism"""
    if not text or len(text.strip()) < 10:
        return {"error": "Text too short", "result": text}

    messages = [
        {"role": "user", "content": f"{REWRITE_PROMPT}\n\nOriginal text to rewrite:\n\n{text}"}
    ]
    
    rewritten = await get_response(messages)
    
    # Calculate a rough "originality score" based on word overlap
    orig_words = set(text.lower().split())
    new_words = set(rewritten.lower().split())
    overlap = len(orig_words & new_words) / max(len(orig_words), 1)
    originality = round((1 - overlap) * 100, 1)

    return {
        "original": text,
        "rewritten": rewritten,
        "originality_score": f"{originality}%",
        "word_count_original": len(text.split()),
        "word_count_rewritten": len(rewritten.split()),
    }
