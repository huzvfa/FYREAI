"""
FYRE AI — File Upload Routes
Handles PDF, DOCX, TXT uploads for AI analysis
"""

from fastapi import APIRouter, UploadFile, File, HTTPException
from services.file_parser import parse_file

router = APIRouter()

MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB


@router.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    """Upload a file and extract its text content"""
    content = await file.read()
    
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(413, "File too large. Max 10MB.")

    allowed = [".pdf", ".docx", ".doc", ".txt"]
    ext = "." + file.filename.split(".")[-1].lower() if "." in file.filename else ""
    if ext not in allowed:
        raise HTTPException(400, f"Unsupported type. Allowed: {', '.join(allowed)}")

    result = await parse_file(file.filename, content)
    
    if "error" in result:
        raise HTTPException(422, result["error"])

    return {
        "filename": file.filename,
        "size": len(content),
        "text": result["text"],
        "preview": result["text"][:500] + "..." if len(result["text"]) > 500 else result["text"],
        "type": result.get("type", "unknown"),
    }
