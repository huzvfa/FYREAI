"""
FYRE AI — Chat Routes
Handles streaming chat, session history, and web search integration
"""

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import Optional
import json
import uuid

from services.ollama_service import stream_response, check_ollama_status
from services.search_service import web_search, format_context, should_search

router = APIRouter()

# In-memory session store (also persisted to DB)
sessions: dict = {}


class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    use_search: Optional[bool] = None  # None = auto-detect
    file_context: Optional[str] = None


class SessionCreate(BaseModel):
    title: Optional[str] = "New Chat"


@router.get("/status")
async def ollama_status():
    """Check if Ollama is running"""
    return await check_ollama_status()


@router.post("/session")
async def create_session(body: SessionCreate):
    """Create a new chat session"""
    session_id = str(uuid.uuid4())
    sessions[session_id] = {"title": body.title, "messages": []}
    return {"session_id": session_id, "title": body.title}


@router.get("/sessions")
async def list_sessions():
    """List all sessions"""
    return [
        {"session_id": sid, "title": s["title"], "message_count": len(s["messages"])}
        for sid, s in sessions.items()
    ]


@router.get("/session/{session_id}")
async def get_session(session_id: str):
    """Get messages in a session"""
    if session_id not in sessions:
        raise HTTPException(404, "Session not found")
    return sessions[session_id]


@router.delete("/session/{session_id}")
async def delete_session(session_id: str):
    """Delete a chat session"""
    sessions.pop(session_id, None)
    return {"deleted": session_id}


@router.post("/send")
async def send_message(body: ChatRequest):
    """
    Non-streaming chat endpoint.
    Returns full response after generation completes.
    """
    session_id = body.session_id or str(uuid.uuid4())
    if session_id not in sessions:
        sessions[session_id] = {"title": body.message[:40], "messages": []}

    # Decide if web search is needed
    do_search = body.use_search if body.use_search is not None else should_search(body.message)
    context = ""
    search_results = []

    if do_search:
        search_results = await web_search(body.message)
        context = format_context(search_results)

    # Add file context if provided
    if body.file_context:
        context = f"## Uploaded File Content:\n{body.file_context}\n\n" + context

    # Build message history
    sessions[session_id]["messages"].append({"role": "user", "content": body.message})
    messages = sessions[session_id]["messages"][-20:]  # Last 20 messages for context

    # Get full response
    full_response = ""
    async for token in stream_response(messages, context):
        full_response += token

    sessions[session_id]["messages"].append({"role": "assistant", "content": full_response})

    return {
        "session_id": session_id,
        "response": full_response,
        "used_search": do_search,
        "sources": search_results if do_search else [],
    }


@router.post("/stream")
async def stream_message(body: ChatRequest):
    """
    Streaming chat endpoint via Server-Sent Events.
    Returns tokens as they are generated.
    """
    session_id = body.session_id or str(uuid.uuid4())
    if session_id not in sessions:
        sessions[session_id] = {"title": body.message[:40], "messages": []}

    do_search = body.use_search if body.use_search is not None else should_search(body.message)
    context = ""
    search_results = []

    if do_search:
        search_results = await web_search(body.message)
        context = format_context(search_results)

    if body.file_context:
        context = f"## Uploaded File Content:\n{body.file_context}\n\n" + context

    sessions[session_id]["messages"].append({"role": "user", "content": body.message})
    messages = sessions[session_id]["messages"][-20:]

    full_response = []

    async def generate():
        # First send metadata
        yield f"data: {json.dumps({'type': 'meta', 'session_id': session_id, 'searching': do_search, 'sources': search_results})}\n\n"
        
        async for token in stream_response(messages, context):
            full_response.append(token)
            yield f"data: {json.dumps({'type': 'token', 'content': token})}\n\n"
        
        # Save assistant response
        final = "".join(full_response)
        sessions[session_id]["messages"].append({"role": "assistant", "content": final})
        yield f"data: {json.dumps({'type': 'done', 'full_response': final})}\n\n"

    return StreamingResponse(generate(), media_type="text/event-stream")


@router.websocket("/ws/{session_id}")
async def websocket_chat(websocket: WebSocket, session_id: str):
    """WebSocket endpoint for real-time chat"""
    await websocket.accept()
    
    if session_id not in sessions:
        sessions[session_id] = {"title": "New Chat", "messages": []}

    try:
        while True:
            data = await websocket.receive_text()
            payload = json.loads(data)
            user_message = payload.get("message", "")
            use_search = payload.get("use_search", None)
            file_context = payload.get("file_context", "")

            do_search = use_search if use_search is not None else should_search(user_message)
            context = ""
            search_results = []

            if do_search:
                await websocket.send_text(json.dumps({"type": "searching", "query": user_message}))
                search_results = await web_search(user_message)
                context = format_context(search_results)
                await websocket.send_text(json.dumps({"type": "sources", "sources": search_results}))

            if file_context:
                context = f"## Uploaded File Content:\n{file_context}\n\n" + context

            sessions[session_id]["messages"].append({"role": "user", "content": user_message})
            messages = sessions[session_id]["messages"][-20:]

            full_response = []
            async for token in stream_response(messages, context):
                full_response.append(token)
                await websocket.send_text(json.dumps({"type": "token", "content": token}))

            final = "".join(full_response)
            sessions[session_id]["messages"].append({"role": "assistant", "content": final})
            await websocket.send_text(json.dumps({"type": "done", "full_response": final}))

    except WebSocketDisconnect:
        pass
