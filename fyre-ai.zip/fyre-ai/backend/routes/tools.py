"""
FYRE AI — Tools Routes
Plagiarism removal and AI text detection endpoints
"""

from fastapi import APIRouter
from pydantic import BaseModel
from services.plagiarism import remove_plagiarism
from services.ai_detector import detect_ai_text

router = APIRouter()


class TextInput(BaseModel):
    text: str


@router.post("/remove-plagiarism")
async def plagiarism_remover(body: TextInput):
    """Rewrite text to remove plagiarism"""
    result = await remove_plagiarism(body.text)
    return result


@router.post("/detect-ai")
async def ai_detector(body: TextInput):
    """Detect if text was written by AI"""
    result = detect_ai_text(body.text)
    return result
