"""
FYRE AI — Backend Entry Point
FastAPI + Ollama + DuckDuckGo + WebSockets
100% Free, No API Keys Required
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import uvicorn

from database.db import init_db
from routes import chat, tools, files

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    await init_db()
    print("🔥 FYRE AI Backend Starting...")
    print("📡 Ollama endpoint: http://localhost:11434")
    print("🌐 API ready at: http://localhost:8000")
    yield
    # Shutdown
    print("FYRE AI shutting down.")

app = FastAPI(
    title="FYRE AI Engine",
    description="Your own free AI engine — no API keys needed",
    version="1.0.0",
    lifespan=lifespan
)

# CORS — allow frontend dev server
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register route groups
app.include_router(chat.router,  prefix="/api/chat",  tags=["Chat"])
app.include_router(tools.router, prefix="/api/tools", tags=["Tools"])
app.include_router(files.router, prefix="/api/files", tags=["Files"])

@app.get("/")
async def root():
    return {"message": "🔥 FYRE AI Engine is running", "status": "online"}

@app.get("/api/health")
async def health():
    return {"status": "healthy", "engine": "FYRE AI v1.0"}

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
