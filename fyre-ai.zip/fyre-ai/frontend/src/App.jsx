import React, { useState, useEffect } from 'react'
import Sidebar from './components/Sidebar'
import ChatWindow from './components/ChatWindow'
import PromptBar from './components/PromptBar'
import ToolsPanel from './components/ToolsPanel'
import { useChat } from './hooks/useChat'
import { api } from './utils/api'

// Animated background particles (CSS-only, no canvas)
function Background() {
  return (
    <div className="bg-layer" aria-hidden>
      <div className="bg-orb orb-1" />
      <div className="bg-orb orb-2" />
      <div className="bg-orb orb-3" />
      <div className="bg-grid" />
      <style>{`
        .bg-layer {
          position: fixed;
          inset: 0;
          pointer-events: none;
          z-index: 0;
          overflow: hidden;
        }
        .bg-orb {
          position: absolute;
          border-radius: 50%;
          filter: blur(80px);
          opacity: 0.12;
          animation: fireFlicker 6s ease-in-out infinite;
        }
        .orb-1 {
          width: 600px; height: 600px;
          background: radial-gradient(circle, #ff4500, transparent);
          top: -200px; left: -100px;
          animation-delay: 0s;
        }
        .orb-2 {
          width: 400px; height: 400px;
          background: radial-gradient(circle, #ff6b00, transparent);
          bottom: -100px; right: 100px;
          animation-delay: 2s;
          opacity: 0.08;
        }
        .orb-3 {
          width: 300px; height: 300px;
          background: radial-gradient(circle, #ffd700, transparent);
          top: 40%; right: -50px;
          animation-delay: 4s;
          opacity: 0.05;
        }
        .bg-grid {
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(255,69,0,0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,69,0,0.03) 1px, transparent 1px);
          background-size: 60px 60px;
        }
      `}</style>
    </div>
  )
}

export default function App() {
  const [activeTab, setActiveTab] = useState('chat')
  const [sessions, setSessions] = useState([])
  const [ollamaStatus, setOllamaStatus] = useState(null)

  const {
    messages,
    isStreaming,
    isSearching,
    sources,
    sessionId,
    sendMessage,
    clearMessages,
    editMessage,
  } = useChat()

  // Check Ollama on mount
  useEffect(() => {
    api.checkStatus().then(setOllamaStatus)
  }, [])

  // Load sessions
  const loadSessions = () => {
    api.getSessions().then(setSessions).catch(() => {})
  }

  useEffect(() => { loadSessions() }, [sessionId])

  const handleNewChat = () => {
    clearMessages()
    setActiveTab('chat')
  }

  const handleDeleteSession = async (sid) => {
    await api.deleteSession(sid)
    loadSessions()
    if (sid === sessionId) clearMessages()
  }

  return (
    <div className="app">
      <Background />
      <div className="app-inner">
        <Sidebar
          sessions={sessions}
          currentSessionId={sessionId}
          onNewChat={handleNewChat}
          onSelectSession={() => {}}
          onDeleteSession={handleDeleteSession}
          activeTab={activeTab}
          onTabChange={setActiveTab}
        />

        <main className="main">
          {ollamaStatus?.status === 'offline' && (
            <div className="ollama-warning">
              ⚠️ Ollama is not running. Run <code>ollama serve</code> then <code>ollama pull mistral</code> to start FYRE AI engine.
            </div>
          )}

          {activeTab === 'chat' ? (
            <>
              <ChatWindow
                messages={messages}
                isStreaming={isStreaming}
                isSearching={isSearching}
                sources={sources}
                onEditMessage={editMessage}
              />
              <PromptBar
                onSend={sendMessage}
                isStreaming={isStreaming}
              />
            </>
          ) : (
            <ToolsPanel activeTab={activeTab} />
          )}
        </main>
      </div>

      <style>{`
        .app {
          width: 100vw;
          height: 100vh;
          position: relative;
          overflow: hidden;
        }
        .app-inner {
          position: relative;
          z-index: 1;
          display: flex;
          height: 100%;
        }
        .main {
          flex: 1;
          display: flex;
          flex-direction: column;
          height: 100%;
          overflow: hidden;
          min-width: 0;
        }
        .ollama-warning {
          padding: 12px 24px;
          background: rgba(255,69,0,0.08);
          border-bottom: 1px solid rgba(255,69,0,0.2);
          font-size: 13px;
          color: var(--fire-glow);
          flex-shrink: 0;
          animation: fadeIn 0.3s ease;
        }
        .ollama-warning code {
          font-family: var(--font-mono);
          background: rgba(255,255,255,0.08);
          padding: 1px 6px;
          border-radius: 4px;
          font-size: 12px;
        }
      `}</style>
    </div>
  )
}
