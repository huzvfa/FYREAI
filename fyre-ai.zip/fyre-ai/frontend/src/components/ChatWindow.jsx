import React, { useEffect, useRef } from 'react'
import MessageBubble from './MessageBubble'

function WelcomeScreen() {
  return (
    <div className="welcome">
      <div className="welcome-fire">🔥</div>
      <h1 className="welcome-title">
        FYRE <span>AI</span>
      </h1>
      <p className="welcome-sub">Your intelligent assistant — powered by local AI</p>
      <div className="welcome-chips">
        {[
          { icon: '📐', text: 'Solve math problems step by step' },
          { icon: '🔍', text: 'Search the web in real-time' },
          { icon: '📝', text: 'Write & improve essays' },
          { icon: '💻', text: 'Debug and explain code' },
          { icon: '🧹', text: 'Remove plagiarism from text' },
          { icon: '🕵️', text: 'Detect AI-generated content' },
        ].map((c, i) => (
          <div key={i} className="chip" style={{ animationDelay: `${i * 0.08}s` }}>
            <span>{c.icon}</span> {c.text}
          </div>
        ))}
      </div>

      <style>{`
        .welcome {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          height: 100%;
          gap: 16px;
          animation: fadeIn 0.6s ease;
          padding: 40px 20px;
        }
        .welcome-fire {
          font-size: 64px;
          animation: fireFlicker 2s ease-in-out infinite;
          filter: drop-shadow(0 0 20px rgba(255,69,0,0.5));
        }
        .welcome-title {
          font-size: 48px;
          font-weight: 800;
          letter-spacing: 4px;
          color: var(--text-primary);
        }
        .welcome-title span {
          background: linear-gradient(135deg, #ff4500, #ffd700);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .welcome-sub {
          font-size: 15px;
          color: var(--text-secondary);
          letter-spacing: 0.5px;
        }
        .welcome-chips {
          display: flex;
          flex-wrap: wrap;
          gap: 10px;
          justify-content: center;
          max-width: 580px;
          margin-top: 16px;
        }
        .chip {
          padding: 10px 16px;
          background: var(--bg-glass);
          border: 1px solid var(--border);
          border-radius: 50px;
          font-size: 13px;
          color: var(--text-secondary);
          backdrop-filter: var(--blur-sm);
          animation: fadeIn 0.4s ease both;
          cursor: default;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          gap: 6px;
        }
        .chip:hover {
          background: var(--accent-soft);
          border-color: var(--accent-border);
          color: var(--text-primary);
          transform: translateY(-1px);
        }
      `}</style>
    </div>
  )
}

function SearchingIndicator({ isSearching }) {
  if (!isSearching) return null
  return (
    <div className="searching-bar">
      <span className="search-spin" />
      Searching the web...
      <style>{`
        .searching-bar {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 8px 24px;
          font-size: 12px;
          color: var(--fire-glow);
          font-family: var(--font-mono);
          animation: fadeIn 0.2s ease;
        }
        .search-spin {
          width: 12px; height: 12px;
          border: 2px solid var(--fire-core);
          border-top-color: transparent;
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
          display: inline-block;
        }
      `}</style>
    </div>
  )
}

function SourcesBar({ sources }) {
  if (!sources?.length) return null
  return (
    <div className="sources-bar">
      <span className="sources-label">🌐 Sources</span>
      {sources.slice(0, 4).map((s, i) => (
        <a key={i} href={s.url} target="_blank" rel="noopener noreferrer" className="source-chip">
          {s.title?.slice(0, 40) || new URL(s.url).hostname}
        </a>
      ))}
      <style>{`
        .sources-bar {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 24px;
          flex-wrap: wrap;
          animation: fadeIn 0.3s ease;
        }
        .sources-label {
          font-size: 11px;
          color: var(--text-muted);
          font-weight: 600;
          letter-spacing: 0.5px;
        }
        .source-chip {
          padding: 3px 10px;
          background: rgba(34,197,94,0.08);
          border: 1px solid rgba(34,197,94,0.2);
          border-radius: 20px;
          font-size: 11px;
          color: rgba(34,197,94,0.8);
          text-decoration: none;
          transition: all 0.15s;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 200px;
        }
        .source-chip:hover {
          background: rgba(34,197,94,0.15);
          color: #22c55e;
        }
      `}</style>
    </div>
  )
}

export default function ChatWindow({ messages, isStreaming, isSearching, sources, onEditMessage }) {
  const bottomRef = useRef(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  return (
    <div className="chat-window">
      {messages.length === 0 ? (
        <WelcomeScreen />
      ) : (
        <div className="messages-list">
          <SearchingIndicator isSearching={isSearching} />
          <SourcesBar sources={sources} />
          {messages.map((msg, idx) => (
            <MessageBubble
              key={msg.id || idx}
              message={msg}
              onEdit={(newContent) => onEditMessage(idx, newContent)}
            />
          ))}
          <div ref={bottomRef} />
        </div>
      )}

      <style>{`
        .chat-window {
          flex: 1;
          overflow-y: auto;
          display: flex;
          flex-direction: column;
        }
        .messages-list {
          display: flex;
          flex-direction: column;
          padding: 8px 0;
          min-height: 100%;
        }
      `}</style>
    </div>
  )
}
