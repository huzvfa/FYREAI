import React, { useState } from 'react'
import { api } from '../utils/api'

function ResultCard({ result, type }) {
  if (!result) return null

  if (type === 'plagiarism') {
    return (
      <div className="result-card">
        <div className="result-header">
          <span className="result-badge success">✓ Rewritten</span>
          <span className="result-score">{result.originality_score} original</span>
        </div>
        <div className="result-text">{result.rewritten}</div>
        <button
          className="copy-btn"
          onClick={() => navigator.clipboard.writeText(result.rewritten)}
        >Copy Result</button>
      </div>
    )
  }

  if (type === 'detector') {
    const pct = parseFloat(result.ai_percentage)
    const color = pct >= 75 ? '#ff4444' : pct >= 50 ? '#ff8c00' : '#22c55e'
    return (
      <div className="result-card">
        <div className="result-header">
          <span className="result-badge" style={{ borderColor: color, color }}>{result.verdict}</span>
          <span className="result-score" style={{ color }}>{result.ai_percentage} AI</span>
        </div>
        <div className="probability-bar">
          <div className="probability-fill" style={{ width: result.ai_percentage, background: color }} />
        </div>
        <div className="result-flags">
          {result.flags.length === 0 && <p className="flag-item">No AI patterns detected</p>}
          {result.flags.map((f, i) => (
            <p key={i} className="flag-item">• {f}</p>
          ))}
        </div>
        <p className="result-meta">Confidence: {result.confidence} · Words: {result.word_count}</p>
      </div>
    )
  }
}

export default function ToolsPanel({ activeTab }) {
  const [text, setText] = useState('')
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleRun = async () => {
    if (!text.trim()) return
    setLoading(true)
    setResult(null)
    setError('')
    try {
      let res
      if (activeTab === 'plagiarism') res = await api.removePlagiarism(text)
      else res = await api.detectAI(text)
      setResult(res)
    } catch {
      setError('Error: Backend not reachable. Start the backend first.')
    } finally {
      setLoading(false)
    }
  }

  const config = {
    plagiarism: {
      title: 'Plagiarism Remover',
      icon: '🧹',
      desc: 'Paste any text to rewrite it as fully original content',
      btn: 'Rewrite Text',
      placeholder: 'Paste your text here...',
    },
    detector: {
      title: 'AI Text Detector',
      icon: '🕵️',
      desc: 'Detect whether text was written by AI or a human',
      btn: 'Analyze Text',
      placeholder: 'Paste text to analyze...',
    },
  }[activeTab] || {}

  return (
    <div className="tools-panel">
      <div className="tools-header">
        <span className="tools-icon">{config.icon}</span>
        <div>
          <h2 className="tools-title">{config.title}</h2>
          <p className="tools-desc">{config.desc}</p>
        </div>
      </div>

      <textarea
        className="tools-textarea"
        value={text}
        onChange={e => setText(e.target.value)}
        placeholder={config.placeholder}
        rows={10}
      />

      <div className="tools-actions">
        <span className="word-count">{text.trim().split(/\s+/).filter(Boolean).length} words</span>
        <button
          className="run-btn"
          onClick={handleRun}
          disabled={!text.trim() || loading}
        >
          {loading ? <><span className="mini-spin" /> Processing...</> : config.btn}
        </button>
        <button className="clear-btn" onClick={() => { setText(''); setResult(null) }}>Clear</button>
      </div>

      {error && <p className="tools-error">{error}</p>}
      <ResultCard result={result} type={activeTab} />

      <style>{`
        .tools-panel {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 16px;
          padding: 28px 32px;
          overflow-y: auto;
        }
        .tools-header {
          display: flex;
          align-items: center;
          gap: 16px;
          padding-bottom: 16px;
          border-bottom: 1px solid var(--border);
        }
        .tools-icon { font-size: 36px; }
        .tools-title {
          font-size: 22px;
          font-weight: 700;
          color: var(--text-primary);
        }
        .tools-desc { font-size: 13px; color: var(--text-secondary); margin-top: 2px; }
        .tools-textarea {
          width: 100%;
          min-height: 200px;
          background: rgba(255,255,255,0.03);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          padding: 16px;
          color: var(--text-primary);
          font-family: var(--font-main);
          font-size: 14px;
          line-height: 1.7;
          resize: vertical;
          outline: none;
          transition: border 0.2s;
        }
        .tools-textarea:focus { border-color: rgba(255,69,0,0.4); }
        .tools-actions {
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .word-count {
          font-size: 12px;
          color: var(--text-muted);
          font-family: var(--font-mono);
          margin-right: auto;
        }
        .run-btn {
          padding: 10px 24px;
          background: linear-gradient(135deg, var(--fire-plasma), var(--fire-core));
          border: none;
          border-radius: 10px;
          color: white;
          font-family: var(--font-main);
          font-size: 14px;
          font-weight: 600;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 8px;
          transition: all 0.2s;
          box-shadow: 0 4px 16px rgba(255,69,0,0.3);
        }
        .run-btn:hover:not(:disabled) {
          transform: translateY(-1px);
          box-shadow: 0 6px 24px rgba(255,69,0,0.5);
        }
        .run-btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .clear-btn {
          padding: 10px 18px;
          background: var(--bg-glass);
          border: 1px solid var(--border);
          border-radius: 10px;
          color: var(--text-secondary);
          font-family: var(--font-main);
          font-size: 14px;
          cursor: pointer;
        }
        .mini-spin {
          width: 14px; height: 14px;
          border: 2px solid white;
          border-top-color: transparent;
          border-radius: 50%;
          display: inline-block;
          animation: spin 0.8s linear infinite;
        }
        .tools-error {
          color: #ff6b6b;
          font-size: 13px;
          padding: 10px 14px;
          background: rgba(255,69,0,0.05);
          border: 1px solid rgba(255,69,0,0.2);
          border-radius: 8px;
        }
        .result-card {
          background: rgba(255,255,255,0.03);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          padding: 20px;
          display: flex;
          flex-direction: column;
          gap: 12px;
          animation: fadeIn 0.3s ease;
        }
        .result-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }
        .result-badge {
          padding: 4px 12px;
          border: 1px solid rgba(34,197,94,0.4);
          border-radius: 20px;
          font-size: 12px;
          color: #22c55e;
          font-weight: 600;
        }
        .result-score {
          font-size: 14px;
          font-weight: 700;
          font-family: var(--font-mono);
        }
        .result-text {
          font-size: 14px;
          line-height: 1.75;
          color: var(--text-primary);
          white-space: pre-wrap;
        }
        .copy-btn {
          padding: 7px 16px;
          background: var(--accent-soft);
          border: 1px solid var(--accent-border);
          border-radius: 8px;
          color: var(--fire-glow);
          font-size: 13px;
          cursor: pointer;
          align-self: flex-start;
        }
        .probability-bar {
          height: 6px;
          background: rgba(255,255,255,0.06);
          border-radius: 3px;
          overflow: hidden;
        }
        .probability-fill {
          height: 100%;
          border-radius: 3px;
          transition: width 0.8s ease;
        }
        .result-flags {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .flag-item {
          font-size: 13px;
          color: var(--text-secondary);
        }
        .result-meta {
          font-size: 11px;
          color: var(--text-muted);
          font-family: var(--font-mono);
        }
      `}</style>
    </div>
  )
}
