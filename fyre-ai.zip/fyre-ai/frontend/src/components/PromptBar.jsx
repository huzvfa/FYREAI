import React, { useState, useRef, useEffect, useCallback } from 'react'
import { useVoice } from '../hooks/useVoice'
import { api } from '../utils/api'

export default function PromptBar({ onSend, isStreaming, onFileUpload }) {
  const [value, setValue] = useState('')
  const [useSearch, setUseSearch] = useState(true)
  const [uploadedFile, setUploadedFile] = useState(null)
  const [uploading, setUploading] = useState(false)
  const textareaRef = useRef(null)
  const fileInputRef = useRef(null)
  const [focused, setFocused] = useState(false)

  const handleTranscript = useCallback((text) => {
    setValue(prev => prev ? prev + ' ' + text : text)
    textareaRef.current?.focus()
  }, [])

  const { isListening, supported, startListening, stopListening } = useVoice({ onTranscript: handleTranscript })

  const adjustHeight = () => {
    const t = textareaRef.current
    if (!t) return
    t.style.height = 'auto'
    t.style.height = Math.min(t.scrollHeight, 200) + 'px'
  }

  useEffect(() => { adjustHeight() }, [value])

  const handleSubmit = () => {
    if (!value.trim() || isStreaming) return
    onSend({
      message: value.trim(),
      useSearch,
      fileContext: uploadedFile?.text || null,
    })
    setValue('')
    setUploadedFile(null)
    if (textareaRef.current) textareaRef.current.style.height = 'auto'
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSubmit()
    }
  }

  const handleFileSelect = async (e) => {
    const file = e.target.files[0]
    if (!file) return
    setUploading(true)
    try {
      const result = await api.uploadFile(file)
      setUploadedFile({ name: file.name, text: result.text, preview: result.preview })
      onFileUpload?.(result)
    } catch (err) {
      alert('File upload failed. Check backend.')
    } finally {
      setUploading(false)
      e.target.value = ''
    }
  }

  return (
    <div className="prompt-outer">
      {uploadedFile && (
        <div className="file-badge">
          <span>📄 {uploadedFile.name}</span>
          <button onClick={() => setUploadedFile(null)}>×</button>
        </div>
      )}
      <div className={`prompt-bar ${focused ? 'focused' : ''} ${isStreaming ? 'streaming' : ''}`}>
        <div className="prompt-tools left">
          <button
            className={`tool-btn ${useSearch ? 'active' : ''}`}
            onClick={() => setUseSearch(!useSearch)}
            title={useSearch ? 'Web search: ON' : 'Web search: OFF'}
          >
            🌐
          </button>
          <button
            className="tool-btn"
            onClick={() => fileInputRef.current?.click()}
            title="Upload file"
            disabled={uploading}
          >
            {uploading ? <span className="mini-spin" /> : '📎'}
          </button>
          <input ref={fileInputRef} type="file" accept=".pdf,.txt,.docx" onChange={handleFileSelect} style={{ display: 'none' }} />
        </div>

        <textarea
          ref={textareaRef}
          className="prompt-input"
          value={value}
          onChange={e => setValue(e.target.value)}
          onKeyDown={handleKeyDown}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          placeholder={isStreaming ? 'FYRE AI is thinking...' : 'Ask anything — FYRE AI is ready 🔥'}
          rows={1}
          disabled={isStreaming}
        />

        <div className="prompt-tools right">
          {supported && (
            <button
              className={`tool-btn voice ${isListening ? 'recording' : ''}`}
              onClick={isListening ? stopListening : startListening}
              title={isListening ? 'Stop recording' : 'Voice input'}
            >
              {isListening ? '🔴' : '🎙️'}
            </button>
          )}
          <button
            className={`send-btn ${value.trim() && !isStreaming ? 'ready' : ''}`}
            onClick={handleSubmit}
            disabled={!value.trim() || isStreaming}
            title="Send"
          >
            {isStreaming ? <span className="mini-spin" /> : '↑'}
          </button>
        </div>
      </div>

      <div className="prompt-hints">
        {useSearch && <span className="hint web">🌐 Web search active</span>}
        {uploadedFile && <span className="hint file">📄 File attached</span>}
        {isListening && <span className="hint voice">🎙️ Listening...</span>}
        <span className="hint key">⏎ Send · ⇧⏎ New line</span>
      </div>

      <style>{`
        .prompt-outer {
          padding: 12px 20px 20px;
          flex-shrink: 0;
        }
        .file-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 6px 12px;
          background: var(--accent-soft);
          border: 1px solid var(--accent-border);
          border-radius: 8px;
          font-size: 12px;
          color: var(--fire-glow);
          margin-bottom: 8px;
          animation: fadeIn 0.2s ease;
        }
        .file-badge button {
          background: none; border: none;
          color: var(--text-muted); cursor: pointer;
          font-size: 16px; line-height: 1;
        }
        .prompt-bar {
          display: flex;
          align-items: flex-end;
          gap: 8px;
          background: rgba(255,255,255,0.04);
          border: 1px solid var(--border);
          border-radius: 18px;
          padding: 10px 12px;
          backdrop-filter: var(--blur);
          -webkit-backdrop-filter: var(--blur);
          transition: all 0.25s ease;
          position: relative;
        }
        .prompt-bar.focused {
          border-color: rgba(255,69,0,0.5);
          box-shadow: 0 0 0 3px rgba(255,69,0,0.08), var(--shadow-fire);
          background: rgba(255,255,255,0.06);
        }
        .prompt-bar.streaming {
          animation: borderGlow 2s ease infinite;
        }
        .prompt-tools {
          display: flex;
          align-items: center;
          gap: 4px;
          flex-shrink: 0;
        }
        .tool-btn {
          width: 34px; height: 34px;
          background: transparent;
          border: 1px solid transparent;
          border-radius: 8px;
          cursor: pointer;
          font-size: 16px;
          display: flex; align-items: center; justify-content: center;
          transition: all 0.15s;
          color: var(--text-muted);
        }
        .tool-btn:hover {
          background: var(--bg-glass-hover);
          border-color: var(--border);
        }
        .tool-btn.active {
          background: var(--accent-soft);
          border-color: var(--accent-border);
        }
        .tool-btn.voice.recording {
          animation: pulseGlow 1s ease infinite;
        }
        .prompt-input {
          flex: 1;
          background: transparent;
          border: none;
          outline: none;
          color: var(--text-primary);
          font-family: var(--font-main);
          font-size: 15px;
          line-height: 1.6;
          resize: none;
          min-height: 24px;
          max-height: 200px;
          padding: 4px 4px;
        }
        .prompt-input::placeholder {
          color: var(--text-muted);
        }
        .send-btn {
          width: 38px; height: 38px;
          background: var(--bg-glass);
          border: 1px solid var(--border);
          border-radius: 50%;
          cursor: pointer;
          font-size: 18px;
          color: var(--text-muted);
          display: flex; align-items: center; justify-content: center;
          transition: all 0.2s;
          flex-shrink: 0;
        }
        .send-btn.ready {
          background: linear-gradient(135deg, var(--fire-plasma), var(--fire-core));
          border-color: transparent;
          color: white;
          box-shadow: 0 4px 16px rgba(255,69,0,0.4);
        }
        .send-btn.ready:hover {
          transform: scale(1.08);
          box-shadow: 0 6px 24px rgba(255,69,0,0.6);
        }
        .send-btn:disabled { cursor: not-allowed; opacity: 0.5; }
        .mini-spin {
          width: 14px; height: 14px;
          border: 2px solid currentColor;
          border-top-color: transparent;
          border-radius: 50%;
          display: inline-block;
          animation: spin 0.8s linear infinite;
        }
        .prompt-hints {
          display: flex;
          gap: 12px;
          padding: 6px 4px 0;
          flex-wrap: wrap;
        }
        .hint {
          font-size: 11px;
          color: var(--text-muted);
          font-family: var(--font-mono);
        }
        .hint.web { color: rgba(34, 197, 94, 0.7); }
        .hint.file { color: rgba(255, 165, 0, 0.7); }
        .hint.voice { color: var(--fire-core); }
        .hint.key { margin-left: auto; }
      `}</style>
    </div>
  )
}
