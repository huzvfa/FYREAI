import React, { useState } from 'react'

export default function Sidebar({ sessions, currentSessionId, onNewChat, onSelectSession, onDeleteSession, activeTab, onTabChange }) {
  const [collapsed, setCollapsed] = useState(false)

  return (
    <aside className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
      <div className="sidebar-header">
        <div className="logo">
          <span className="logo-icon">🔥</span>
          {!collapsed && <span className="logo-text">FYRE <span className="logo-sub">AI</span></span>}
        </div>
        <button className="collapse-btn" onClick={() => setCollapsed(!collapsed)} title="Toggle sidebar">
          {collapsed ? '→' : '←'}
        </button>
      </div>

      {!collapsed && (
        <>
          <button className="new-chat-btn" onClick={onNewChat}>
            <span>+</span> New Chat
          </button>

          <nav className="tool-nav">
            {[
              { id: 'chat', label: 'Chat', icon: '💬' },
              { id: 'plagiarism', label: 'Plagiarism', icon: '🧹' },
              { id: 'detector', label: 'AI Detect', icon: '🕵️' },
            ].map(tab => (
              <button
                key={tab.id}
                className={`tool-nav-btn ${activeTab === tab.id ? 'active' : ''}`}
                onClick={() => onTabChange(tab.id)}
              >
                <span>{tab.icon}</span> {tab.label}
              </button>
            ))}
          </nav>

          <div className="chat-history">
            <p className="history-label">Recent Chats</p>
            {sessions.length === 0 && (
              <p className="history-empty">No chats yet</p>
            )}
            {sessions.map(session => (
              <div
                key={session.session_id}
                className={`history-item ${currentSessionId === session.session_id ? 'active' : ''}`}
                onClick={() => onSelectSession(session.session_id)}
              >
                <span className="history-title">{session.title || 'Untitled'}</span>
                <button
                  className="history-delete"
                  onClick={e => { e.stopPropagation(); onDeleteSession(session.session_id) }}
                  title="Delete"
                >×</button>
              </div>
            ))}
          </div>

          <div className="sidebar-footer">
            <div className="status-dot online" />
            <span>FYRE AI Engine</span>
          </div>
        </>
      )}

      <style>{`
        .sidebar {
          width: var(--sidebar-width);
          min-width: var(--sidebar-width);
          height: 100%;
          background: rgba(5,5,8,0.95);
          border-right: 1px solid var(--border);
          display: flex;
          flex-direction: column;
          transition: all 0.3s cubic-bezier(0.4,0,0.2,1);
          overflow: hidden;
          position: relative;
          z-index: 10;
        }
        .sidebar.collapsed {
          width: 60px;
          min-width: 60px;
        }
        .sidebar-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 20px 16px;
          border-bottom: 1px solid var(--border);
        }
        .logo {
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .logo-icon {
          font-size: 22px;
          animation: fireFlicker 2s ease-in-out infinite;
        }
        .logo-text {
          font-size: 18px;
          font-weight: 800;
          letter-spacing: 2px;
          color: var(--text-primary);
        }
        .logo-sub {
          color: var(--fire-core);
        }
        .collapse-btn {
          background: var(--bg-glass);
          border: 1px solid var(--border);
          color: var(--text-secondary);
          width: 28px;
          height: 28px;
          border-radius: 6px;
          cursor: pointer;
          font-size: 13px;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .collapse-btn:hover {
          background: var(--accent-soft);
          border-color: var(--accent-border);
          color: var(--accent);
        }
        .new-chat-btn {
          margin: 16px 12px 8px;
          padding: 12px 16px;
          background: linear-gradient(135deg, var(--fire-plasma), var(--fire-core));
          border: none;
          border-radius: var(--radius-sm);
          color: white;
          font-family: var(--font-main);
          font-size: 14px;
          font-weight: 600;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 8px;
          transition: all 0.2s;
          letter-spacing: 0.5px;
          box-shadow: 0 4px 20px rgba(255,69,0,0.3);
        }
        .new-chat-btn:hover {
          transform: translateY(-1px);
          box-shadow: 0 6px 30px rgba(255,69,0,0.5);
        }
        .new-chat-btn span {
          font-size: 18px;
          line-height: 1;
        }
        .tool-nav {
          padding: 8px 12px;
          display: flex;
          flex-direction: column;
          gap: 4px;
          border-bottom: 1px solid var(--border);
          margin-bottom: 8px;
        }
        .tool-nav-btn {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 9px 12px;
          background: transparent;
          border: 1px solid transparent;
          border-radius: var(--radius-xs);
          color: var(--text-secondary);
          font-family: var(--font-main);
          font-size: 13px;
          cursor: pointer;
          transition: all 0.2s;
          text-align: left;
        }
        .tool-nav-btn:hover {
          background: var(--bg-glass);
          color: var(--text-primary);
        }
        .tool-nav-btn.active {
          background: var(--accent-soft);
          border-color: var(--accent-border);
          color: var(--fire-glow);
        }
        .chat-history {
          flex: 1;
          overflow-y: auto;
          padding: 0 12px;
        }
        .history-label {
          font-size: 10px;
          font-weight: 600;
          letter-spacing: 1.5px;
          color: var(--text-muted);
          text-transform: uppercase;
          margin: 12px 4px 8px;
        }
        .history-empty {
          font-size: 12px;
          color: var(--text-muted);
          padding: 8px 4px;
        }
        .history-item {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 9px 10px;
          border-radius: var(--radius-xs);
          cursor: pointer;
          transition: all 0.15s;
          border: 1px solid transparent;
          margin-bottom: 2px;
        }
        .history-item:hover {
          background: var(--bg-glass);
        }
        .history-item.active {
          background: var(--accent-soft);
          border-color: var(--accent-border);
        }
        .history-title {
          font-size: 12px;
          color: var(--text-secondary);
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          flex: 1;
        }
        .history-item.active .history-title {
          color: var(--text-primary);
        }
        .history-delete {
          background: none;
          border: none;
          color: var(--text-muted);
          cursor: pointer;
          font-size: 16px;
          line-height: 1;
          padding: 0 4px;
          opacity: 0;
          transition: opacity 0.2s;
        }
        .history-item:hover .history-delete {
          opacity: 1;
        }
        .history-delete:hover {
          color: var(--fire-core);
        }
        .sidebar-footer {
          padding: 16px;
          border-top: 1px solid var(--border);
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 11px;
          color: var(--text-muted);
        }
        .status-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: #22c55e;
          box-shadow: 0 0 6px #22c55e;
        }
      `}</style>
    </aside>
  )
}
