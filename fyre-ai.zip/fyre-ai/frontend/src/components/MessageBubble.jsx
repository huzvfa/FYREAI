import React, { useState } from 'react'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism'

function TypingIndicator() {
  return (
    <div className="typing-indicator">
      <span /><span /><span />
      <style>{`
        .typing-indicator {
          display: flex; align-items: center; gap: 4px; padding: 4px 0;
        }
        .typing-indicator span {
          width: 6px; height: 6px;
          background: var(--fire-core);
          border-radius: 50%;
          animation: typing 1.4s ease-in-out infinite;
        }
        .typing-indicator span:nth-child(2) { animation-delay: 0.2s; }
        .typing-indicator span:nth-child(3) { animation-delay: 0.4s; }
      `}</style>
    </div>
  )
}

export default function MessageBubble({ message, onEdit }) {
  const [editing, setEditing] = useState(false)
  const [editValue, setEditValue] = useState(message.content)
  const [copied, setCopied] = useState(false)

  const isUser = message.role === 'user'

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleEditSubmit = () => {
    if (editValue.trim() && editValue !== message.content) {
      onEdit(editValue.trim())
    }
    setEditing(false)
  }

  return (
    <div className={`message-wrap ${isUser ? 'user' : 'assistant'}`}>
      <div className="message-avatar">
        {isUser ? '👤' : '🔥'}
      </div>
      <div className="message-body">
        <div className="message-meta">
          <span className="message-role">{isUser ? 'You' : 'FYRE AI'}</span>
          <span className="message-time">
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>

        {editing ? (
          <div className="edit-area">
            <textarea
              value={editValue}
              onChange={e => setEditValue(e.target.value)}
              rows={3}
              autoFocus
              onKeyDown={e => {
                if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleEditSubmit() }
                if (e.key === 'Escape') setEditing(false)
              }}
            />
            <div className="edit-actions">
              <button onClick={handleEditSubmit} className="btn-fire">Send</button>
              <button onClick={() => setEditing(false)} className="btn-ghost">Cancel</button>
            </div>
          </div>
        ) : (
          <div className={`message-content ${message.error ? 'error' : ''}`}>
            {message.streaming && !message.content ? (
              <TypingIndicator />
            ) : isUser ? (
              <p>{message.content}</p>
            ) : (
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={{
                  code({ inline, className, children }) {
                    const lang = /language-(\w+)/.exec(className || '')?.[1]
                    return !inline && lang ? (
                      <SyntaxHighlighter style={oneDark} language={lang} PreTag="div">
                        {String(children).replace(/\n$/, '')}
                      </SyntaxHighlighter>
                    ) : (
                      <code className="inline-code">{children}</code>
                    )
                  },
                  table({ children }) {
                    return <div className="table-wrap"><table>{children}</table></div>
                  }
                }}
              >
                {message.content}
              </ReactMarkdown>
            )}
            {message.streaming && message.content && (
              <span className="cursor-blink">▊</span>
            )}
          </div>
        )}

        {!editing && !message.streaming && (
          <div className="message-actions">
            <button onClick={handleCopy} className="action-btn" title="Copy">
              {copied ? '✓' : '⎘'}
            </button>
            {isUser && (
              <button onClick={() => setEditing(true)} className="action-btn" title="Edit">✏️</button>
            )}
          </div>
        )}
      </div>

      <style>{`
        .message-wrap {
          display: flex;
          gap: 14px;
          padding: 20px 24px;
          animation: fadeIn 0.3s ease;
          transition: background 0.2s;
        }
        .message-wrap:hover { background: rgba(255,255,255,0.015); }
        .message-wrap.user { flex-direction: row-reverse; }
        .message-avatar {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          background: var(--bg-glass);
          border: 1px solid var(--border);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          flex-shrink: 0;
          backdrop-filter: var(--blur-sm);
        }
        .message-wrap.assistant .message-avatar {
          border-color: var(--accent-border);
          box-shadow: 0 0 12px rgba(255,69,0,0.15);
        }
        .message-body {
          flex: 1;
          max-width: 80%;
          display: flex;
          flex-direction: column;
          gap: 6px;
        }
        .message-wrap.user .message-body { align-items: flex-end; }
        .message-meta {
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .message-wrap.user .message-meta { flex-direction: row-reverse; }
        .message-role {
          font-size: 12px;
          font-weight: 700;
          letter-spacing: 0.5px;
          color: var(--text-secondary);
        }
        .message-wrap.assistant .message-role { color: var(--fire-glow); }
        .message-time {
          font-size: 10px;
          color: var(--text-muted);
          font-family: var(--font-mono);
        }
        .message-content {
          font-size: 14.5px;
          line-height: 1.75;
          color: var(--text-primary);
        }
        .message-wrap.user .message-content {
          background: var(--accent-soft);
          border: 1px solid var(--accent-border);
          border-radius: 16px 4px 16px 16px;
          padding: 12px 16px;
          animation: promptSlide 0.3s ease;
        }
        .message-content.error { color: #ff6b6b; }
        .message-content p { margin-bottom: 0.5em; }
        .message-content p:last-child { margin-bottom: 0; }
        .message-content h1,.message-content h2,.message-content h3 {
          margin: 1em 0 0.5em;
          color: var(--text-primary);
        }
        .message-content ul,.message-content ol {
          padding-left: 1.5em;
          margin: 0.5em 0;
        }
        .message-content li { margin: 0.25em 0; }
        .message-content blockquote {
          border-left: 3px solid var(--fire-core);
          padding-left: 12px;
          margin: 0.5em 0;
          color: var(--text-secondary);
        }
        .inline-code {
          background: rgba(255,69,0,0.1);
          border: 1px solid rgba(255,69,0,0.2);
          border-radius: 4px;
          padding: 1px 6px;
          font-family: var(--font-mono);
          font-size: 13px;
          color: var(--fire-glow);
        }
        .table-wrap { overflow-x: auto; margin: 0.5em 0; }
        .message-content table {
          width: 100%;
          border-collapse: collapse;
          font-size: 13px;
        }
        .message-content th,.message-content td {
          padding: 8px 12px;
          border: 1px solid var(--border);
          text-align: left;
        }
        .message-content th {
          background: var(--accent-soft);
          color: var(--fire-glow);
          font-weight: 600;
        }
        .cursor-blink {
          color: var(--fire-core);
          animation: typing 0.8s step-end infinite;
          margin-left: 1px;
        }
        .message-actions {
          display: flex;
          gap: 4px;
          opacity: 0;
          transition: opacity 0.2s;
        }
        .message-wrap:hover .message-actions { opacity: 1; }
        .action-btn {
          background: var(--bg-glass);
          border: 1px solid var(--border);
          border-radius: 6px;
          padding: 4px 8px;
          font-size: 12px;
          color: var(--text-muted);
          cursor: pointer;
          transition: all 0.15s;
        }
        .action-btn:hover {
          background: var(--accent-soft);
          border-color: var(--accent-border);
          color: var(--accent);
        }
        .edit-area textarea {
          width: 100%;
          background: var(--bg-glass);
          border: 1px solid var(--accent-border);
          border-radius: var(--radius-sm);
          padding: 10px 14px;
          color: var(--text-primary);
          font-family: var(--font-main);
          font-size: 14px;
          resize: none;
          outline: none;
        }
        .edit-actions {
          display: flex;
          gap: 8px;
          margin-top: 6px;
        }
        .btn-fire {
          padding: 6px 16px;
          background: var(--fire-core);
          border: none;
          border-radius: 6px;
          color: white;
          font-family: var(--font-main);
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
        }
        .btn-ghost {
          padding: 6px 16px;
          background: var(--bg-glass);
          border: 1px solid var(--border);
          border-radius: 6px;
          color: var(--text-secondary);
          font-family: var(--font-main);
          font-size: 13px;
          cursor: pointer;
        }
      `}</style>
    </div>
  )
}
