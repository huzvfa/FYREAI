import { useState, useCallback, useRef } from 'react'
import { api, streamSSE } from '../utils/api'

export function useChat() {
  const [messages, setMessages] = useState([])
  const [isStreaming, setIsStreaming] = useState(false)
  const [isSearching, setIsSearching] = useState(false)
  const [sources, setSources] = useState([])
  const [sessionId, setSessionId] = useState(null)
  const abortRef = useRef(null)

  const sendMessage = useCallback(async ({
    message,
    useSearch = undefined,
    fileContext = null,
    editIndex = null,
  }) => {
    if (isStreaming) return

    // If editing, trim history
    let updatedMessages = [...messages]
    if (editIndex !== null) {
      updatedMessages = updatedMessages.slice(0, editIndex)
    }

    // Add user message
    const userMsg = {
      id: Date.now(),
      role: 'user',
      content: message,
      timestamp: new Date(),
    }
    updatedMessages = [...updatedMessages, userMsg]
    setMessages(updatedMessages)
    setSources([])
    setIsStreaming(true)

    // Placeholder assistant message
    const assistantId = Date.now() + 1
    setMessages(prev => [...prev, {
      id: assistantId,
      role: 'assistant',
      content: '',
      timestamp: new Date(),
      streaming: true,
    }])

    try {
      // Create session if needed
      let sid = sessionId
      if (!sid) {
        const session = await api.createSession(message.slice(0, 40))
        sid = session.session_id
        setSessionId(sid)
      }

      const response = await api.sendMessage({
        message,
        sessionId: sid,
        useSearch,
        fileContext,
      })

      for await (const event of streamSSE(response)) {
        if (event.type === 'meta') {
          setIsSearching(event.searching)
        } else if (event.type === 'sources') {
          setSources(event.sources || [])
          setIsSearching(false)
        } else if (event.type === 'token') {
          setMessages(prev => prev.map(m =>
            m.id === assistantId
              ? { ...m, content: m.content + event.content }
              : m
          ))
        } else if (event.type === 'done') {
          setMessages(prev => prev.map(m =>
            m.id === assistantId
              ? { ...m, streaming: false, content: event.full_response }
              : m
          ))
        }
      }
    } catch (err) {
      setMessages(prev => prev.map(m =>
        m.id === assistantId
          ? { ...m, streaming: false, content: '⚠️ Error: Could not reach FYRE AI engine. Make sure Ollama is running.', error: true }
          : m
      ))
    } finally {
      setIsStreaming(false)
      setIsSearching(false)
    }
  }, [messages, sessionId, isStreaming])

  const clearMessages = useCallback(() => {
    setMessages([])
    setSessionId(null)
    setSources([])
  }, [])

  const editMessage = useCallback((index, newContent) => {
    sendMessage({ message: newContent, editIndex: index })
  }, [sendMessage])

  return {
    messages,
    isStreaming,
    isSearching,
    sources,
    sessionId,
    sendMessage,
    clearMessages,
    editMessage,
  }
}
