const BASE = '/api'

export const api = {
  async sendMessage({ message, sessionId, useSearch, fileContext }) {
    const res = await fetch(`${BASE}/chat/stream`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message,
        session_id: sessionId,
        use_search: useSearch,
        file_context: fileContext || null,
      }),
    })
    return res
  },

  async createSession(title = 'New Chat') {
    const res = await fetch(`${BASE}/chat/session`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title }),
    })
    return res.json()
  },

  async getSessions() {
    const res = await fetch(`${BASE}/chat/sessions`)
    return res.json()
  },

  async getSession(sessionId) {
    const res = await fetch(`${BASE}/chat/session/${sessionId}`)
    return res.json()
  },

  async deleteSession(sessionId) {
    await fetch(`${BASE}/chat/session/${sessionId}`, { method: 'DELETE' })
  },

  async checkStatus() {
    try {
      const res = await fetch(`${BASE}/chat/status`)
      return res.json()
    } catch {
      return { status: 'offline' }
    }
  },

  async detectAI(text) {
    const res = await fetch(`${BASE}/tools/detect-ai`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
    })
    return res.json()
  },

  async removePlagiarism(text) {
    const res = await fetch(`${BASE}/tools/remove-plagiarism`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
    })
    return res.json()
  },

  async uploadFile(file) {
    const form = new FormData()
    form.append('file', file)
    const res = await fetch(`${BASE}/files/upload`, {
      method: 'POST',
      body: form,
    })
    return res.json()
  },
}

export async function* streamSSE(response) {
  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''

  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    buffer += decoder.decode(value, { stream: true })
    const lines = buffer.split('\n')
    buffer = lines.pop()
    for (const line of lines) {
      if (line.startsWith('data: ')) {
        try {
          yield JSON.parse(line.slice(6))
        } catch {}
      }
    }
  }
}
